package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.jar.Attributes;

public class Register extends AppCompatActivity {

    EditText name, num;
    Button Reg;
    TextView lbtn;
    private DatabaseReference mdatabasereference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);



        name = findViewById(R.id.name);
        num = findViewById(R.id.num);


        Reg = findViewById(R.id.Reg);
        lbtn = findViewById(R.id.lbtn);
        mdatabasereference = FirebaseDatabase.getInstance().getReference();

        Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name, Num;

                Name = name.getText().toString();
                Num = num.getText().toString();



                if (name.equals("")) ;
                {
                    mdatabasereference.child(Name);
                    Toast.makeText(Register.this, "name is blank", Toast.LENGTH_SHORT).show();
                }
                if (num.equals("")) ;
                {
                    mdatabasereference.child(Num);
                    Toast.makeText(Register.this, "name is blank", Toast.LENGTH_SHORT).show();
                }


            }


        });
        lbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent R =new Intent(Register.this,MainActivity.class);
                startActivity(R);
                finish();
            }
        });
    }
}

